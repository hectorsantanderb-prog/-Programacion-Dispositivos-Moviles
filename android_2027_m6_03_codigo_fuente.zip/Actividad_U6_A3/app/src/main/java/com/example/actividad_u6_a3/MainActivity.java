package com.example.actividad_u6_a3;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private static final String URL_PRINCIPAL = "https://api.publicapis.org/entries";
    private static final String URL_RESPALDO = "https://jsonplaceholder.typicode.com/posts?_limit=5";

    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.enableEdgeToEdge(getWindow());
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvResultado = findViewById(R.id.tvResultado);
        Button btnConsultar = findViewById(R.id.btnConsultar);

        btnConsultar.setOnClickListener(v -> {
            tvResultado.setText("Consultando servicio REST (HTTP GET)...");
            realizarPeticionGet();
        });
    }

    private void realizarPeticionGet() {
        new Thread(() -> {
            String resultado;
            try {
                resultado = ejecutarHttpGet(URL_PRINCIPAL);
            } catch (Exception ePrincipal) {
                try {
                    String respuestaRespaldo = ejecutarHttpGet(URL_RESPALDO);
                    resultado = "Aviso: " + URL_PRINCIPAL + " no respondió (" + ePrincipal.getMessage() + ").\n\n"
                            + "Resultado HTTP GET desde servicio REST de respaldo (" + URL_RESPALDO + "):\n\n"
                            + respuestaRespaldo;
                } catch (Exception eRespaldo) {
                    resultado = "Error al realizar HTTP GET: " + eRespaldo.getMessage();
                }
            }

            final String textoFinal = resultado;
            runOnUiThread(() -> tvResultado.setText(textoFinal));
        }).start();
    }

    private String ejecutarHttpGet(String urlTexto) throws Exception {
        URL url = new URL(urlTexto);
        HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
        conexion.setRequestMethod("GET");
        conexion.setConnectTimeout(5000);
        conexion.setReadTimeout(5000);

        int codigoRespuesta = conexion.getResponseCode();
        BufferedReader lector = new BufferedReader(new InputStreamReader(
                codigoRespuesta >= 200 && codigoRespuesta < 300
                        ? conexion.getInputStream()
                        : conexion.getErrorStream()
        ));

        StringBuilder respuesta = new StringBuilder();
        respuesta.append("HTTP ").append(codigoRespuesta).append(" OK\n\n");
        String linea;
        while ((linea = lector.readLine()) != null) {
            respuesta.append(linea).append("\n");
        }
        lector.close();
        conexion.disconnect();

        return respuesta.toString();
    }
}