package mx.fca.aviones;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AvionAdapter extends RecyclerView.Adapter<AvionHolder> {

    private ArrayList<Avion> aviones;
    private ArrayList<Colision> colisiones;
    private final int columnas;
    private final int filas;

    public AvionAdapter(ArrayList<Avion> aviones, ArrayList<Colision> colisiones, int columnas, int filas) {
        this.aviones = aviones;
        this.colisiones = colisiones;
        this.columnas = columnas;
        this.filas = filas;
    }

    public void actualizarDatos(ArrayList<Avion> aviones, ArrayList<Colision> colisiones) {
        this.aviones = aviones;
        this.colisiones = colisiones;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public AvionHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.avion_view, parent, false);
        return new AvionHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AvionHolder holder, int position) {
        int x = position % columnas;
        int y = position / columnas;

        // 1. Verificar primero si existe una colisión en (x, y)
        if (colisiones != null) {
            for (Colision colision : colisiones) {
                if (colision.x == x && colision.y == y) {
                    holder.imgAvion.setImageResource(colision.getImage());
                    return;
                }
            }
        }

        // 2. Si no hay colisión, verificar si hay un avión en (x, y)
        if (aviones != null) {
            for (Avion avion : aviones) {
                if (avion.x == x && avion.y == y) {
                    holder.imgAvion.setImageResource(avion.getImage());
                    return;
                }
            }
        }

        // 3. Celda vacía
        holder.imgAvion.setImageDrawable(null);
    }

    @Override
    public int getItemCount() {
        return columnas * filas;
    }
}