package mx.fca.aviones;

import android.util.Log;

import java.util.ArrayList;

public class Plano {

    public ArrayList<Avion> aviones;
    public ArrayList<Colision> colisiones;
    public int col;
    public int row;
    public int noPaso;

    Plano(int noPaso, ArrayList<Avion> aviones, ArrayList<Colision> colisiones) {
        this.noPaso = noPaso;
        this.aviones = aviones;
        this.colisiones = colisiones;

        int tmpX = 0;
        int tmpY = 0;
        for (Avion avion : aviones) {
            if (avion.x > tmpX) {
                tmpX = avion.x;
            }
            if (avion.y > tmpY) {
                tmpY = avion.y;
            }
        }
        col = tmpX;
        row = tmpY;

        Log.i("Aviones max de columna", String.valueOf(col));
        Log.i("Aviones max de renglon", String.valueOf(row));
    }

    public Plano next() {
        return Analizador.next(noPaso + 1, this);
    }

    public Plano prev() {
        if (noPaso > 0) {
            return Analizador.prev(noPaso - 1);
        }
        return this;
    }

    public int getNumeroColisiones() {
        return colisiones != null ? colisiones.size() : 0;
    }

    public int getNumeroAviones() {
        return aviones != null ? aviones.size() : 0;
    }
}