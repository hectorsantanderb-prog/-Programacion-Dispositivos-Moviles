package mx.fca.aviones;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    private static final int COLUMNAS = 5;
    private static final int FILAS = 5;

    Button btnNext;
    Button btnPrev;
    TextView tvPasos;
    TextView tvColisiones;
    Plano plano;
    RecyclerView listaAviones;
    AvionAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listaAviones = findViewById(R.id.listaAviones);
        btnNext = findViewById(R.id.btnNext);
        btnPrev = findViewById(R.id.btnPrev);
        tvPasos = findViewById(R.id.tvPasos);
        tvColisiones = findViewById(R.id.tvColisiones);

        plano = Planificador.crearRutaInicial();
        adapter = new AvionAdapter(plano.aviones, plano.colisiones, COLUMNAS, FILAS);
        listaAviones.setAdapter(adapter);
        listaAviones.setLayoutManager(new GridLayoutManager(this, COLUMNAS));

        actualizarVista();

        btnNext.setOnClickListener(v -> {
            plano = plano.next();
            actualizarVista();
        });

        btnPrev.setOnClickListener(v -> {
            plano = plano.prev();
            actualizarVista();
        });
    }

    private void actualizarVista() {
        tvPasos.setText("Pasos: " + plano.noPaso);
        tvColisiones.setText("Colisiones: " + plano.getNumeroColisiones());
        adapter.actualizarDatos(plano.aviones, plano.colisiones);
    }
}