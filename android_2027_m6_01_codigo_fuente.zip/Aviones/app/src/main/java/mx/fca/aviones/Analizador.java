package mx.fca.aviones;

import java.util.ArrayList;
import java.util.HashMap;

public class Analizador {

    static HashMap<Integer, Plano> memoria = new HashMap<>();

    public static Plano inicializa(Plano plano) {
        memoria.clear();
        memoria.put(0, plano);
        return plano;
    }

    public static Plano next(int noPaso, Plano plano) {
        if (memoria.containsKey(noPaso)) {
            return memoria.get(noPaso);
        } else {
            ArrayList<Avion> nuevosAviones = new ArrayList<>();
            ArrayList<Colision> colisiones = new ArrayList<>();

            // 1. Calcular la nueva posición creando una copia de cada avión
            for (Avion avion : plano.aviones) {
                int nuevoX = avion.x;
                int nuevoY = avion.y;

                switch (avion.direccion) {
                    case NORTH:
                        nuevoY = avion.y - 1;
                        break;
                    case SOUTH:
                        nuevoY = avion.y + 1;
                        break;
                    case EAST:
                        nuevoX = avion.x + 1;
                        break;
                    case WEST:
                        nuevoX = avion.x - 1;
                        break;
                }
                nuevosAviones.add(new Avion(avion.direccion, nuevoX, nuevoY));
            }

            // 2. Detectar colisiones usando un HashMap (clave: "x,y", valor: cantidad de aviones)
            HashMap<String, Integer> conteoPosiciones = new HashMap<>();
            for (Avion avion : nuevosAviones) {
                String clave = avion.x + "," + avion.y;
                int cantidad = conteoPosiciones.containsKey(clave) ? conteoPosiciones.get(clave) : 0;
                conteoPosiciones.put(clave, cantidad + 1);
            }

            // Si en una coordenada hay 2 o más aviones, registramos una colisión
            for (String clave : conteoPosiciones.keySet()) {
                if (conteoPosiciones.get(clave) > 1) {
                    String[] coords = clave.split(",");
                    int x = Integer.parseInt(coords[0]);
                    int y = Integer.parseInt(coords[1]);
                    colisiones.add(new Colision(x, y));
                }
            }

            Plano planoNuevo = new Plano(noPaso, nuevosAviones, colisiones);
            memoria.put(noPaso, planoNuevo);
            return planoNuevo;
        }
    }

    public static Plano prev(int noPaso) {
        if (noPaso < 0) {
            return memoria.get(0);
        }
        return memoria.get(noPaso);
    }
}